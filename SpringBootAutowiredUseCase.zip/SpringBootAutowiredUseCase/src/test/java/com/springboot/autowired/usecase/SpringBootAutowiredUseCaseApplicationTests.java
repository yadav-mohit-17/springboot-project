package com.springboot.autowired.usecase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAutowiredUseCaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
